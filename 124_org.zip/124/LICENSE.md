MIT license

Copyright (c) 2023 Henry Ruhs
