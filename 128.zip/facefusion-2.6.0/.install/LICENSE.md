CC-BY-4.0 license

Copyright (c) 2024 Henry Ruhs
