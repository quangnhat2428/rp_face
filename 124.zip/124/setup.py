file_path = "/content/extracted/124/facefusion/uis/components/output.py"

with open(file_path, "r") as file:
    lines = file.readlines()

if not lines[-1].strip() == "start(output_path)":
    with open(file_path, "a") as file:
        file.write("\nstart(output_path)")
    print("Đã thêm dòng 'start(output_path)' vào cuối file!")
else:
    print("Dòng 'start(output_path)' đã tồn tại ở cuối file.")